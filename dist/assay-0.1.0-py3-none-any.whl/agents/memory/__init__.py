"""Assay Agent Infrastructure — memory and tools subpackages."""
