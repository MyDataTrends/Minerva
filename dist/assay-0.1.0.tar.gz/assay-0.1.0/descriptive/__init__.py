"""Descriptive statistics utilities."""
