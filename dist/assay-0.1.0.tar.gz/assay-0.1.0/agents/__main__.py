"""Allow running agents as a module: python -m agents ..."""
from agents.cli import main

if __name__ == "__main__":
    main()
