MODEL_ALLOWLIST = {
    "regression": ["lightgbm", "xgboost", "ridge"],
    "classification": ["lightgbm", "xgboost", "lr"],
}
