from examples.selenium_decode_demo import main

if __name__ == "__main__":
    main()